﻿using MySql.Data.MySqlClient;

namespace GestionConges
{
    public static class Db
    {
        private static string connectionString = "Server=localhost;Database=gsb_opti;Uid=root;Pwd=;";

        public static MySqlConnection GetConnection()
        {
            return new MySqlConnection(connectionString);
        }
    }
}
